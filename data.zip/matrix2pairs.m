clc
clear
addpath('E:\000 COVID-19\11 MRPMC-master\python\DrugVirus')
% LD=importdata('virus_drug_association39vs121.csv'); 
LD=importdata('interaction.mat');

[m1,n2]=size(LD);
% color block matrix
% figure(1);
% image(Adj,'CDataMapping','scaled');  
% colorbar;

%%%%%%%%%%%%%%%%%%% matrix converted to pairs %%%%%%%%%%%%%%%%%%%%%%%%%
index_pos=find(LD);
index_neg=find(LD==0);
[pp,~]=size(index_pos);
[jj,~]=size(index_neg);
A=zeros((pp+jj),3);
for i=1:pp
[X,Y]=ind2sub(size(LD),index_pos(i));
A(i,1)=X;
A(i,2)=Y;
A(i,3)=1;
end
for j=1:jj
[X,Y]=ind2sub(size(LD),index_neg(j));
A(pp+j,1)=X;
A(pp+j,2)=Y;
A(pp+j,3)=0;
end
save('UnbalancedSample.mat','A');

% [SL_GIP,SR_GIP]=gkl(m1,n2,LD);

