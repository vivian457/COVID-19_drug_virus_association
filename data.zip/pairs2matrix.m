%%%%%%%%%%%%%%%%%%%%% pairs converted to matrix %%%%%%%%%%%%%%%%%%%%%%%%%%
clc
clear
addpath('E:\000 COVID-19\03 GCNMDA-master\data\DrugVirus')
adj=importdata('adj.txt');
drugs = importdata('drugs.xlsx');
virus = importdata('viruses.xlsx');
[m,~]=size(virus.data);
[n,~]=size(drugs.data);
LD=zeros(m,n);
[pp,~]=size(adj);

for i=1:pp

LD(adj(i,2),adj(i,1)) = adj(i,3);

end

save('interaction.mat','LD');