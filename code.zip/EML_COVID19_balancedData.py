# -*- coding:utf-8 -*-
import matplotlib.pyplot as plt
from sklearn.ensemble import GradientBoostingClassifier
from sklearn.utils import shuffle
from sklearn import metrics
from sklearn.model_selection import KFold
from sklearn import svm
import lightgbm as lgb
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Dense,Dropout
from tensorflow.keras.optimizers import SGD
from sklearn import datasets
import gc
import xlrd
import os
import random
from sklearn.preprocessing import label_binarize
from sklearn.linear_model import LogisticRegression
import matplotlib.pyplot as plt
from sklearn.metrics import accuracy_score,precision_recall_curve,f1_score,roc_curve,roc_auc_score,auc,confusion_matrix, \
    precision_score,recall_score,cohen_kappa_score
from sklearn.metrics import matthews_corrcoef
import datetime as dt
from sklearn.preprocessing import StandardScaler
from statsmodels.stats.proportion import proportion_confint
from sklearn.calibration import calibration_curve
import joblib
import shap_interpretation
from numpy.random import seed
from Sampling_negative import *
from sklearn.metrics import brier_score_loss
import pandas as pd
import numpy as np
from sklearn.model_selection import StratifiedKFold
from sklearn.model_selection import validation_curve
from sklearn.svm import SVC
import math
import time
from sklearn.ensemble import RandomForestClassifier, ExtraTreesClassifier, IsolationForest
from sklearn.linear_model import LogisticRegression
import scipy.io as scio
from DeepMF import *
from DMF import *

# from __future__ import print_function
import torch
import torch.nn
from torch.nn import init
from torch.nn.parameter import Parameter
from torch._jit_internal import weak_module, weak_script_method
from sklearn.decomposition import FastICA
import math
import numpy as np
import os
import logging
from ray.kmean_torch import kmeans_core

torch.manual_seed(2019)

seed(2020)

path = './results/' + dt.datetime.now().strftime('%Y%m%d-%H-%M') + '-impute-svd'
os.makedirs(path,exist_ok=True)
save_models = './save_models'
os.makedirs(save_models,exist_ok=True)


def get_metrics_system(k, Y_test, predict_value):
    m = confusion_matrix(Y_test, predict_value.round(), labels=[1, 0])
    TP_ = m[0][0]
    FN_ = m[0][1]
    FP_ = m[1][0]
    TN_ = m[1][1]
    Accuracy = accuracy_score(Y_test, predict_value.round())         ## Accuracy = float((TP_ + TN_) / (TP_+FN_+FP_+TN_))
    F1 = f1_score(Y_test, predict_value.round())                     ## F1 = 2 * precision * recall / (precision+recall)
    kappa = cohen_kappa_score(Y_test, predict_value.round())
    Recall = recall_score(Y_test, predict_value.round())             ## recall = TP/(TP+FN)
    Precision = precision_score(Y_test, predict_value.round())       ## precision = TP/(TP+FP)
    Sensitivity = float(TP_ / (TP_ + FN_))                          ## Sensitivity = Recall = m[0][0]/ m[0][0] + m[0][1]
    Specificity = float(TN_ / (FP_ + TN_))
    PPV = Precision                                                 ## PPV = Precision = TP/(TP+FP)
    NPV = float(TN_ / (TN_ + FN_))
    AUROC = roc_auc_score(Y_test, predict_value)  ## 计算AUC(比较测试集的原始标签，测试集的分类预测概率分数)
    # MCC = matthews_corrcoef(Y_test, predict_value.round())
    lower_, upper_ = proportion_confint(TP_ + TN_, (TP_ + FN_ + FP_ + TN_), 0.05, method='normal')
    print("Accuracy:", "{:.4}".format(Accuracy), ", in-95%-CI:", '[', "{:.4}".format(lower_), "{:.4}".format(upper_),
          ']')  ## Accuracy = (TP_ + TN_)/(TP_+FN_+FP_+TN_)
    lower_, upper_ = proportion_confint(TP_, (TP_ + FN_), 0.05, method='normal')  ## Sensitivity = Recall = TP_ /(TP_+FN_)
    print("Sensitivity/Recall:", "{:.4}".format(Sensitivity), ", in-95%-CI:", '[', "{:.4}".format(lower_),
          "{:.4}".format(upper_), ']')
    lower_, upper_ = proportion_confint(TN_,(FP_ + TN_), 0.05, method='normal')
    print("Specificity:", "{:.4}".format(Specificity), ", in-95%-CI:", '[', "{:.4}".format(lower_), "{:.4}".format(upper_),
          ']')  ## Specificity = TN_ / (FP_ + TN_)
    fpr_, tpr_, thr_ = roc_curve(Y_test, predict_value,pos_label=1)  ## ’roc_curve()‘与’auc()‘计算的auc和通过混淆矩阵求出来的结果一致
    plt.plot(fpr_, tpr_)
    plt.show()
    # np.savetxt(path+'x_FPR_ROC%d.csv' % k, fpr_, delimiter=',')
    # np.savetxt(path+'y_TPR_ROC%d.csv' % k, tpr_, delimiter=',')
    p_, r_, _ = precision_recall_curve(Y_test, predict_value)
    AUPR = auc(r_, p_)
    Brier = brier_score_loss(Y_test, predict_value)
    # plt.plot(p_, r_)
    # plt.show()
    # np.savetxt(path+'x_Precision_PRcurve%d.csv' % k, p_, delimiter=',')
    # np.savetxt(path+'y_Recall_PRcurve%d.csv' % k, r_, delimiter=',')
    print("Accuracy——F1——Sensitivity——Specificity——PPV——NPV——AUPR——AUROC——Brier")
    print("{:.4}".format(Accuracy), "{:.4}".format(F1), "{:.4}".format(Recall), "{:.4}".format(Specificity),
          "{:.4}".format(PPV), "{:.4}".format(NPV), "{:.4}".format(AUPR), "{:.4}".format(AUROC), "{:.4}".format(Brier))
    print('———————————————————————————————————————————————————————————————————————————————————————————————————')
    return Accuracy, F1, Recall, Specificity, PPV, NPV, AUPR, AUROC, Brier


def sigmoid(a):
    return 1 / (1 + np.exp(-a))

def votingEnsemble(svm, gbdt, mlp, weights, mode):
    voting_proba = np.zeros((len(svm), ))
    voting_label = np.zeros((len(svm), ))
    all_proba = np.hstack((svm.reshape(len(mlp), 1), gbdt.reshape(len(mlp), 1), mlp.reshape(len(mlp), 1)))
    if mode == 'soft':
        for i in range(len(all_proba)):
            voting_proba[i] = (all_proba[i][0]*weights[0] + all_proba[i][1]*weights[1] +
                                  all_proba[i][2]*weights[2])/np.sum(weights)
            if voting_proba[i] >= 0.5:
                voting_label[i] = 1
            else:
                voting_label[i] = 0
    elif mode == 'hard':
        for i in range(len(all_proba)):
            val2 = [n for n in all_proba[i] if n >= 0.5]
            val1 = [n for n in all_proba[i] if n < 0.5]
            if len(val2) >= 2:
                voting_proba[i] = np.array(val2).sum()/len(val2)
                voting_label[i] = 1
            if len(val1) >= 2:
                voting_proba[i] = np.array(val1).sum() / len(val1)
                voting_label[i] = 0
    return [voting_label, voting_proba]

def train(X,Y,seed):

    X,Y = shuffle(X, Y, random_state=seed)  # 'random_state=None'表示多次运行shuffle会得到不同的随机序列
    kf = StratifiedKFold(n_splits=5, shuffle=True, random_state=None)
    # kf = KFold(n_splits=5)

    clf = svm.SVC(C=1.0,
                  kernel='linear',
                  degree=4,
                  gamma='scale',
                  coef0=0.0,
                  shrinking=True,
                  probability=True,
                  tol=0.001,
                  cache_size=200,
                  class_weight='balanced',
                  verbose=False,
                  max_iter=-1,
                  decision_function_shape='ovr',
                  break_ties=False,
                  random_state=15)
    clf2 = lgb.LGBMClassifier(boosting_type='gbdt',
                              max_depth=13,
                              num_leaves=32,
                              learning_rate=0.1,
                              n_estimators=120,
                              random_state=13)

    # clf3 = Sequential()
    # clf3.add(Dense(X.shape[1],activation='relu',input_dim=X.shape[1]))
    # clf3.add(Dropout(0.5))
    # clf3.add(Dense(128,activation='relu'))
    # clf3.add(Dropout(0.5))
    # clf3.add(Dense(64,activation='relu'))
    # clf3.add(Dropout(0.5))
    # clf3.add(Dense(1,activation='sigmoid'))
    # sgd = SGD(lr=0.03,decay=1e-6,momentum=0.9,nesterov=True)
    # clf3.compile(loss='binary_crossentropy',
    #              optimizer=sgd,
    #              metrics=['accuracy'])
    clf3 = RandomForestClassifier(n_estimators=120, max_depth=12)

    clf4 = DeepMF()

    print("开始训练!")
    fold = 0
    metric1 = np.zeros((1, 9))
    metric2 = np.zeros((1, 9))
    metric3 = np.zeros((1, 9))
    metric4 = np.zeros((1, 9))

    for train_index, test_index in kf.split(X, Y):
        fold = fold + 1
        X_train = X[train_index]
        Y_train = Y[train_index]
        X_test = X[test_index]
        Y_test = Y[test_index]
    # for fold in range(5):
    #     data = scio.loadmat('CV1.mat')
    #     X_train = data["X_train"]
    #     Y_train = data["Y_train"]
    #     X_test = data["X_test"]
    #     Y_test = data["Y_test"]

        print("%dth-round %dth-fold CV is running……:" % (seed + 1, fold))
        # 训练模型
        clf4.fit(X_train, Y_train, n_batch, delta=0.00001, alpha=0.01)
        DMF_predict_value = clf4.predict(X_test)
        metric_tmp_DMF = get_metrics_system(1, Y_test, DMF_predict_value)
        print(metric_tmp_DMF)
        ## SVM
        print('SVM')
        clf.fit(X_train, Y_train)
        # 预测类型1的概率分数
        predict_value1_ = clf.predict_proba(X_test)
        predict_value1 = predict_value1_[:, 1]
        # 测试集的预测精度
        # score1 = clf.score(X_test, Y_test)
        # print('SVM测试集的预测精度Accuracy:', score1)
        metric_tmp1 = get_metrics_system(1, Y_test, predict_value1)  # 交叉验证得到的性能合集
        # metric_tmp1 = get_metrics(Y_test, predict_value1)
        metric1 += metric_tmp1
        ## GBDT
        print('GBDT')
        clf2.fit(X_train, Y_train)
        predict_value2_ = clf2.predict_proba(X_test)
        predict_value2 = predict_value2_[:, 1]
        np.savetxt(path+'GBDT_predictedValues_fold_%d.csv' % fold, predict_value2, delimiter=',')
        # score2 = clf2.score(X_test, Y_test)
        # print('GBDT测试集的预测精度Accuracy:', score2)
        metric_tmp2 = get_metrics_system(2, Y_test, predict_value2)  # 交叉验证得到的性能合集
        # metric_tmp2 = get_metrics(Y_test, predict_value2)
        metric2 += metric_tmp2
        ## MLP
        print('MLP')
        # std = StandardScaler()
        # X_train = std.fit_transform(X_train)
        # clf3.X_test = std.transform(X_test)
        # clf3.fit(X_train, Y_train, batch_size=32, epochs=100, verbose=0)
        clf3.fit(X_train, Y_train)
        # Testloss, Testaccuracy = clf3.evaluate(X_test, Y_test, batch_size=32)
        # print('Testloss, Testaccuracy of NN are:', Testloss, Testaccuracy)
        predict_value3 = clf3.predict(X_test)
        # predict_value3 = predict_value3_[:, 1]
        # label3 = clf3.predict(X_test,axis=-1)
        metric_tmp3 = get_metrics_system(3, Y_test, predict_value3)  # 交叉验证得到的性能合集
        # metric_tmp3 = get_metrics(Y_test, predict_value3)
        metric3 += metric_tmp3
        ## SPMCIIP
        print('SPMCIIP')
        weights = np.array([0.3, 0.5, 0.2])
        # predict_ensemble_value = 0.3 * predict_value1 + 0.5 * predict_value2 + 0.2 * predict_value3
        labels_voting, predict_value_voting = votingEnsemble(predict_value1, predict_value2, predict_value3, weights, 'soft')
        metric_tmp4 = get_metrics_system(4, Y_test, predict_value_voting)  # 交叉验证得到的性能合集
        # metric_tmp4 = get_metrics(Y_test, predict_ensemble_value)
        metric4 += metric_tmp4
        # print(metric_tmp1)
        # print(metric_tmp2)
        # print(metric_tmp3)
        # print(metric_tmp4)
        gc.collect()

    print("The results of 1 ROUND 5-fold CV for SVM, GBDT, NN and SPMCIIP are:")
    print("Accuracy——F1——Sensitivity——Specificity——PPV——NPV——AUPR——AUROC——Brier")
    metric1 = pd.DataFrame(metric1 / 5)
    pd.set_option('precision', 4)
    metric2 = pd.DataFrame(metric2 / 5)
    pd.set_option('precision', 4)
    metric3 = pd.DataFrame(metric3 / 5)
    pd.set_option('precision', 4)
    metric4 = pd.DataFrame(metric4 / 5)
    pd.set_option('precision', 4)
    print(metric1)
    print(metric2)
    print(metric3)
    print(metric4)
    return metric1, metric2, metric3, metric4

if __name__ == "__main__":

    ## sample_dat：是所有样本（包括正和负的）的嵌入表示向量
    ## label：是所有样本的标签（正样本是已知的，负样本的先聚类再分别在23个聚类中随机选择的
    ## 将所有位置关联先进行聚类，分成了23类，然后再从每一类中随机挑选50个关联对作为负样本。

    sample_data = np.loadtxt('BalancedData_DrugVirus/X_50.txt', dtype=np.float32)
    label = np.loadtxt('BalancedData_DrugVirus/y_50.txt', dtype=np.integer)
    # sample_data,label = getSample()
    sample_data = np.array(sample_data)
    label = np.array(label)

    circle_time = 10
    result1 = np.zeros((circle_time, 9), float)
    result2 = np.zeros((circle_time, 9), float)
    result3 = np.zeros((circle_time, 9), float)
    result4 = np.zeros((circle_time, 9), float)

    for i in range(circle_time):
        [result1[i,:], result2[i,:], result3[i,:], result4[i,:]] = train(sample_data,label,i)

    average_result1 = np.mean(result1, axis=0)
    std_deviation1 = np.std(result1, axis=0)
    average_result2 = np.mean(result2, axis=0)
    std_deviation2 = np.std(result2, axis=0)
    average_result3 = np.mean(result3, axis=0)
    std_deviation3 = np.std(result3, axis=0)
    average_result4 = np.mean(result4, axis=0)
    std_deviation4 = np.std(result4, axis=0)

    print("————————The finally results of %d" % circle_time,"rounds CV are:———————————————————")
    data1 = pd.DataFrame(
        [average_result1, average_result2, average_result3, average_result4, std_deviation1, std_deviation2, std_deviation3,
         std_deviation4])
    pd.set_option('precision', 4)
    print(data1)
    # transform a to pandas DataFrame
    # a_pd = pd.DataFrame(mirna_data_dict)
    # create writer to write an excel file
    writer = pd.ExcelWriter('EML_COVID19_Performation.xlsx')
    # write in ro file, 'sheet1' is the page title, float_format is the accuracy of data
    post_fix = time.strftime("%m-%d-%H-%M-%S", time.localtime())
    data1.to_excel(writer, 'EML'+post_fix, float_format='%.4f')
    # save file
    writer.save()
    # close writer
    writer.close()
