% Performation test for our EMC-Voting model
% virus-drug association prediction for COVID-19
% ��������ʹ�á����κ󡱵Ĳ���
    clc
    clear
    warning('off');
    addpath('E:\000 COVID-19\01 DLMC-master\DrugVirus\BalancedData_DrugVirus');
    circle_time = 1; %%������֤���еĴ���
    num_models = 3;
    results = zeros(num_models,8);  %% num_models������Ƚϵ�ģ�͸���
    load Sample_50.txt;
    load interaction.mat;
    Sample_index = Sample_50;
    interaction_matrix = LD;
    VS = load('microbesimilarity.txt');
    VF = load('microbefeatures.txt');
    DS = load('drugsimilarity.txt');
    DF = load('drugfeatures.txt');
    for i = 1 : circle_time
        seed = i
        results(:,:,i) = cross_validation(interaction_matrix, Sample_index,VS, VF, DS, DF, seed); %% ����ά����������ÿһ��ѭ���Ľ��
    end
    avg_results = mean(results,3);  %% ���ݵ���ά����ƽ��
    std_results = std(results,1,3);   %% ���ݵ���ά�����׼��      
%     prefix = 'EnsembleMC_performance_adjust';
%     fdatestr =datestr(now,'yyyy.mmm.dd-HH.MM.SS');
%     addr = 'results\';    
%     fout = [addr,prefix,'_',fdatestr,'.mat'];
%     save(fout, 'avg_results','std_results');    
    
function result = cross_validation(interaction_matrix, Sample_index, VS, VF, DS, DF, seed)
    CV=5;    
    rand('state',seed);
    [row,col]=size(interaction_matrix);
    [link_num,~] = size(Sample_index);  %%link_numӦ��Ϊ��������(��������)
    row_index = Sample_index(:,1);      %%���������������������͸���������
    col_index = Sample_index(:,2);
    random_index = randperm(link_num); %���������������(��������)��������
    size_of_CV = round(link_num/CV);   %����������(��������)��ΪCV�ۣ�size_of_CV��ÿһ�۵�������Ŀ��������������һ���Ϊ5�ۣ�
    
    X=importdata('X_50.txt');
    y=importdata('y_50.txt');
    
    result = zeros(3,8);
    for k=1
        if (k~=CV)
           test_row_index = row_index(random_index((size_of_CV*(k-1)+1):(size_of_CV*k)));
           test_col_index = col_index(random_index((size_of_CV*(k-1)+1):(size_of_CV*k)));
           X_test = X(random_index((size_of_CV*(k-1)+1):(size_of_CV*k)),:);
           Y_test = y(random_index((size_of_CV*(k-1)+1):(size_of_CV*k))); 
           X_train = X(random_index(union((1:size_of_CV*(k-1)),((size_of_CV*k+1):end))),:);
           Y_train = y(random_index(union((1:size_of_CV*(k-1)),((size_of_CV*k+1):end))));
        else
            test_row_index = row_index(random_index((size_of_CV*(k-1)+1):end));
            test_col_index = col_index(random_index((size_of_CV*(k-1)+1):end));
            X_test = X(random_index((size_of_CV*(k-1)+1):end),:);
            Y_test = y(random_index((size_of_CV*(k-1)+1):end));
            X_train = X(random_index(1:size_of_CV*(k-1)),:);        
            Y_train = y(random_index(1:size_of_CV*(k-1)));
        end                
%        save('CV5.mat', 'X_test','Y_test','X_train','Y_train');
                
        test_mask = ones(row,col);   
        for i = 1:length(test_row_index)
%               train_set(test_row_index(i)+1,test_col_index(i)+1) = 0;       %% ѵ��������Ԥ�����룬�����ѵ������������ǽ�ԭ�еĽ���������test_set��0֮��Ľ���� 
              test_mask(test_row_index(i)+1,test_col_index(i)+1)  =0;       %% test_mask:ֻ�в�������(��������)��Ӧ��Ԫ��ֵΪ1������ȫΪ0��
        end        
        train_set = interaction_matrix.*test_mask;  %%���������У�����4folds����������Ϊ1����������ֵ��1fold��������������δ֪��������Ϊ0
        fprintf('begin to implement the cross validation:round =%d/%d\n', k, CV);          
        predict_matrix_2 = alg_BNNR(train_set,VS,DS);
        predict_matrix_3 = alg_FRMC(train_set,VS,DS);
        predict_matrix_6 = alg_HGIMC(train_set,VS,VF,DS,DF);
        predict_matrix_7 = alg_GRMF(train_set,VS,DS); 
        proba_2 = predict_matrix_2(:);
        proba_3 = predict_matrix_3(:);
        proba_6 = predict_matrix_6(:);
        proba_7 = predict_matrix_7(:);
        
        test = test_mask(:);
        test_index = find(test==0);
        real_score = interaction_matrix(:);        
        real_score = real_score(test_index);
        proba_2 = proba_2(test_index);   
        proba_3 = proba_3(test_index);  
        proba_6 = proba_6(test_index);  
        proba_7 = proba_7(test_index);       
        proba_GBDT = importdata('GBDT_predictedValues_fold_1.csv');%ͨ������ѧϰԤ�⵽��1-fold�ĸ��ʷ���
        
        model_list1 = [proba_2 proba_6 proba_3 proba_7];
        weights1 = [0.381, 0.143, 0.333, 0.143]; 
        
        model_list2 = [proba_2 proba_6 proba_3 proba_GBDT];
        weights2 = [0.381, 0.143, 0.333, 0.143]; 
        
        predict_matrix1 = alg_EnsembleVoting(model_list1, weights1, 'soft');
        predict_matrix2 = alg_EnsembleVoting(model_list2, weights2, 'soft');
        predict_matrix3 = proba_GBDT;
        
        result(1,:) = result(1,:) + model_evaluate(real_score, predict_matrix1)
%         result(2,:) = result(2,:) + model_evaluate(real_score, predict_matrix2)
%         result(3,:) = result(3,:) + model_evaluate(real_score, predict_matrix3)
        
    end
    disp('The reulst of accuracy, f1, sen, spec, PPV, NPV, aupr and auc are:')
    result = result / CV
end

% 1 IMCMDA
function score_matrix = alg_IMCMDA(interaction,FS,SS)
[nd,nm] = size(interaction);
[kd,km] = gaussiansimilarity(interaction,nd,nm);                
sd = FS;
sm = SS;
sd = (sd+kd)/2;
sm = (sm+km)/2;              
score_matrix = IMC(interaction,sd,sm,70);    %obtain the prediction score matrix
end

% 2 BNNR
function score_matrix = alg_BNNR(LD,LS,DS)
Wrr = DS;
Wdd = LS;
Wdr = LD;
[dn,dr] = size(Wdr);
maxiter = 300;
alpha = 1;
beta = 10;
tol1 = 2*1e-3;
tol2 = 1*1e-5;
T = [Wrr, Wdr'; Wdr, Wdd];
[t1, ~] = size(T);
trIndex = double(T ~= 0);
[WW,~] = BNNR(alpha, beta, T, trIndex, tol1, tol2, maxiter, 0, 1);
M_recovery = WW((t1-dn+1):t1,1:dr);
score_matrix = M_recovery;
end

% 3 FRMC
function score_matrix = alg_FRMC(LD,LS,DS)
addpath('E:\000 COVID-19\01 DLMC-master\helper_functions');
    [m1,n2]=size(LD);
    Adj=[LS,LD;LD',DS];
    interaction=LD;
    index=find(LD);
    [pp,qq]=size(index);
    A=zeros(pp,2);
    for i=1:pp
    [lncRNA,disease]=ind2sub(size(LD),index(i));
    A(i,1)=lncRNA;
    A(i,2)=disease;
    end
    tol = 0.15;
    ran =[0,1];
    i_reuse = 50;
    q_reuse = 10;   
    Adj1=[DS,interaction';interaction,LS]; 
    M = sparse(Adj1);
    t = cputime;
    [X] = fastSVT_Q(M, tol, ran, i_reuse, q_reuse);  %%tol=0.15, ran=[0,1], r_reuse=50,q_reuse=10
    t_SVT = cputime - t;
    F=X((n2+1):(n2+m1),1:n2);
    score_matrix = F;
end

% 4 DMF_jicong fan
function score_matrix = alg_DMF(matrix,Mo)
[m,n] = size(matrix);
r = 2;
s=[r 10 m];% input size, hidden size 1, ..., output size
options.Wp=0.01;
options.Zp=0.01;
options.maxiter=1000;
options.activation_func={'tanh_opt','linear'};
X = matrix;
M = Mo;
[X_DMF,NN_MF]=MC_DMF(X',M',s,options);
Xr=X_DMF';
FlattenedData = Xr(:)';
MappedFlattened = mapminmax(FlattenedData, 0, 1);
score_matrix = reshape(MappedFlattened, size(Xr)); 
end

% % 5 DLMC_jicong fan
function score_matrix = alg_DLMC(Xo,M)
rand('state',0);
% Xo=X.*M;
disp('SAEMC......');
s=[50 10];
options.act_func={'tanh_opt','sigm','tanh_opt','sigm'};%
options.weight_decay=0.001;%
[Xr,AECF]=MC_AE(Xo,M,s,options);
score_matrix = Xr;
end

% 6 HGIMC
function score_matrix = alg_HGIMC(interaction_matrix,VS,VF,DS,DF)
A_DR = interaction_matrix;
[nd,nm] = size(interaction_matrix);
[kd,km] = gaussiansimilarity(interaction_matrix,nd,nm);     
% D = (VS+kd)/2;
% R = (DS+km)/2;
D = VS;
R = DS;
alpha = 10; 
beta = 10; 
gamma = 0.1; 
threshold = 0.7;
maxiter = 500; 
tol1 = 2*1e-3;   
tol2 = 1*1e-5;
% 2.1 Bounded Matrix Completion
trIndex = double(A_DR ~= 0);
[A_bmc, iter] = fBMC(alpha, beta, A_DR, trIndex, tol1, tol2, maxiter, 0, 1);
A_DR0 = A_bmc.*double(A_bmc > threshold);
% 2.2 Gaussian Radial Basis function
A_DD = fGRB(D, 0.5);
A_RR = fGRB(R, 0.5);
% 2.3 Heterogeneous Graph Inference 
score_matrix = fHGI(gamma, A_DD, A_RR, A_DR0);
end

% 7 GRMF
function score_matrix = alg_GRMF(Y,Sd,St)
%alg_grmf predicts DTIs based on the algorithm described in the following paper: 
% Ali Ezzat, Peilin Zhao, Min Wu, Xiao-Li Li and Chee-Keong Kwoh
% (2016) Drug-target interaction prediction with graph-regularized matrix factorization
% INPUT:
%  Y:           interaction matrix
%  Sd:          pairwise row similarities matrix
%  St:          pairwise column similarities matrix
%  test_ind:    indices of test set instances
% OUTPUT:
%  y3:          prediction matrix
%    % parameters 
   global num_iter p k lambda_l lambda_d lambda_t
   num_iter=2; k=100; 
   p=7; lambda_l=0.0313; lambda_d=0.01; lambda_t=0.01;
    %[Sd,St]=addNewSimilarities(Y, [], Sd,St);
    % preprocessing Sd & St
    % (Sparsification of matrices via p-nearest-neighbor graphs)
    Sd = preprocess_PNN(Sd,p);
    St = preprocess_PNN(St,p);
    % Laplacian Matrices
    Dd = diag(sum(Sd));
    Ld = Dd - Sd;
     Ld = (Dd^(-0.5))*Ld*(Dd^(-0.5));
    Dt = diag(sum(St));
    Lt = Dt - St;
     Lt = (Dt^(-0.5))*Lt*(Dt^(-0.5));
    % (W)GRMF
    [A,B] = initializer(Y,k);	% initialize A & B
%     W = ones(size(Y));          % weight matrix W
%     W(test_ind) = 0;            % set W=0 for test instances
    [A,B] = alg_grmf_predict(Y,A,B,Ld,Lt,lambda_l,lambda_d,lambda_t,num_iter);    % update A & B
    % compute prediction matrix
    score_matrix = A*B';
end

% %8 EnsembleaVoting
function score_matrix = alg_EnsembleVoting(modellist, weights, mode)
[row, col] = size(modellist);
voting_proba = zeros(row,1);
voting_label = zeros(row,1);
all_proba = modellist;
    if mode == 'soft'
        for i = 1 : row
             for j = 1:col
                 voting_proba(i) = voting_proba(i)+all_proba(i,j)*weights(j);
             end
             voting_proba(i) = voting_proba(i)/sum(weights);
             if voting_proba(i) >= 0.5
                 voting_label(i) = 1;
             else
                 voting_label(i) = 0;
             end
        end
    elseif mode == 'hard'
        for i = 1 : row
            val1=0; val2=0; len1=0; len2=0; weights_1=0; weights_2=0;
            for j = 1:col
               if all_proba(i,j) >= 0.8
                   val2 = val2 + all_proba(i,j)*weights(j);
                   weights_2 = weights_2+weights(j);
                   len2 = len2+1;
               elseif all_proba(i,j) < 0.8
                   val1 = val1 + all_proba(i,j)*weights(j); 
                   weights_1 = weights_1+weights(j);
                   len1 = len1+1;
               end 
            end
            if len2 >= 2
                voting_proba(i) = val2/weights_2;
                voting_label(i) = 1;
            elseif len1 >= 2
                voting_proba(i) = val1/weights_1;
                voting_label(i) = 0;
            end
        end
    end
%     [m,n] = size(A);
%     score_matrix = reshape(voting_proba,m,n);
score_matrix = voting_proba;
end

function [S]=preprocess_PNN(S,p)
%preprocess_PNN sparsifies S by keeping, for each drug/virus, the "p"
% nearest neighbors (NNs) and discarding the rest. 
    NN_mat = zeros(size(S));
    for j=1:length(NN_mat)
        [~,indx] = sort(S(j,:),'descend');
        indx = indx(1:p+1);     % keep drug/virus j and its "p" NNs
        NN_mat(j,indx) = 1;
    end
    NN_mat = (NN_mat+NN_mat')/2;
    S = NN_mat .* S;
end

function [A,B]=initializer(Y,k)
%initializer initializes the A and B latent feature matrices for either
% of the CMF or GRMF algorithms.%
% INPUT:
%  Y:   interaction matrix
%  k:   number of latent features%
% OUTPUT:
%  A:   latent feature matrix for drugs
%  B:   latent feature matrix for targets
[u,s,v] = svds(Y,k);
A = u*(s^0.5);
B = v*(s^0.5);
    %     % Alternative: Use non-negative matrix factorization
%     k = min(k, min(size(Y)));
%     [A,B] = nnmf(Y,k);
%     B = B';
end

function [A,B]=alg_grmf_predict(Y,A,B,Ld,Lt,lambda_l,lambda_d,lambda_t,num_iter,W)
%alg_grmf_predict performs alternating least squares for GRMF
%
% INPUT:
%  Y:           interaction matrix
%  A:           drug latent feature matrix
%  B:           target latent feature matrix
%  Ld:          drug graph Laplacian
%  Lt:          target graph Laplacian
%  lambda_ldt:  regularization parameters
%  num_iter:    number of iterations for alternating least squares
%  W:           weight matrix
%
% OUTPUT:
%  A:           updated drug latent feature matrix
%  B:           updated target latent feature matrix
%
    K = size(A,2);
    lambda_d_Ld = lambda_d*Ld;          % to avoid 
    lambda_t_Lt = lambda_t*Lt;          % repeated matrix 
    lambda_l_eye_K = lambda_l*eye(K);   % multiplications
    % if no weight matrix is supplied or W is an all-ones matrix...
    if nargin < 10 || isequal(W,ones(size(W)))
        %%%%%%%%%%%%
        %%% GRMF %%%
        %%%%%%%%%%%%
        for z=1:num_iter
            A = (Y*B  - lambda_d_Ld*A) / (B'*B + lambda_l_eye_K);
            B = (Y'*A - lambda_t_Lt*B) / (A'*A + lambda_l_eye_K);
        end 
    else
        %%%%%%%%%%%%%
        %%% WGRMF %%%
        %%%%%%%%%%%%%
        H = W .* Y;
        for z=1:num_iter
%             % for readability...
%             A_old = A;
%             for i=1:size(A,1)
%                 A(i,:) = (H(i,:)*B - lambda_d*Ld(i,:)*A_old) / (B'*diag(W(i,:))*B + lambda*eye(k));
%             end
%             B_old = B;
%             for j=1:size(B,1)
%                 B(j,:) = (H(:,j)'*A - lambda_t*Lt(j,:)*B_old) / (A'*diag(W(:,j))*A + lambda*eye(k));
%             end
            % equivalent, less readable, faster
            A_old = A;
            HB_minus_alpha_Ld_A_old = H*B - lambda_d_Ld*A_old;
            for a=1:size(A,1)
                A(a,:) = HB_minus_alpha_Ld_A_old(a,:) / (B'*diag(W(a,:))*B + lambda_l_eye_K);
            end
            B_old = B;
            HtA_minus_beta_Lt_B_old = H'*A - lambda_t_Lt*B_old;
            for b=1:size(B,1)
                B(b,:) = HtA_minus_beta_Lt_B_old(b,:) / (A'*diag(W(:,b))*A + lambda_l_eye_K);
            end
        end
    end
    
end

function [score]=IMC(A,X,Y,r)
%[M,N]=size(A);
[~,m]=size(X);
[~,n]=size(Y);
W=rand(m,r);
H=rand(n,r);
k=1;
while k<1000
    H=H.*(Y'*A'*(X*W))./(Y'*(Y*H)*(W'*(X')*(X*W))+H);
    W=W.*(X'*A*(Y*H))./(X'*(X*W)*(H'*(Y')*(Y*H))+W);
    %error(k)=0.5*norm(A-X*W*H'*Y','fro')^0.5;%+0.5*norm(W,'fro')^2+0.5*norm(H,'fro')^2;
    k=k+1;
end
score=(X*W)*(Y*H)';
end

function [sd,sm] = integratedsimilarity(FS,FSP,SS,SSP,kd,km)         
sm = FS.*FSP+km.*(-(FSP-1));            
sd = SS.*SSP+kd.*(-(SSP-1));            
end

function [kd,km] = gaussiansimilarity(interaction,nd,nm)
%A: Binary relations between disease and miRNA, 1st column:miRNA, 2nd column:disease
%calculate gamad for Gaussian kernel calculation
 gamad = nd/(norm(interaction,'fro')^2);
%calculate Gaussian kernel for the similarity between disease: kd
C=interaction;
kd=zeros(nd,nd);
D=C*C';
for i=1:nd
    for j=i:nd
        kd(i,j)=exp(-gamad*(D(i,i)+D(j,j)-2*D(i,j)));
    end
end
kd=kd+kd'-diag(diag(kd));
%calculate gamam for Gaussian kernel calculation
gamam = nm/(norm(interaction,'fro')^2);
%calculate Gaussian kernel for the similarity between miRNA: km
km=zeros(nm,nm);
E=C'*C;
for i=1:nm
    for j=i:nm
        km(i,j)=exp(-gamam*(E(i,i)+E(j,j)-2*E(i,j)));
    end
end
km=km+km'-diag(diag(km));
end

function result = model_evaluate(real_score,predict_score)  
%     test = test_mask(:);
%     test_index = find(test==0);
% %     real_score = interaction_matrix(:);
% %     predict_score = predict_matrix(:);
%     real_score = interaction_matrix(test_index);
%     predict_score = predict_matrix(test_index);    
    aupr_ = AUPR(real_score,predict_score)
    auc_ = AUC(real_score,predict_score)
    [X_roc,Y_roc,THRE,auc,OPTROCPT,SUBY,SUBYNAMES] = perfcurve(real_score,predict_score,1);
    [X_pr,Y_pr,tpr_pr,aupr] = perfcurve(real_score,predict_score,1, 'xCrit', 'reca', 'yCrit', 'prec');
    [sen,spec,PPV,NPV,accuracy,f1] = evaluation_metric(real_score,predict_score);
    result = [accuracy,f1,sen,spec,PPV,NPV,aupr,auc];
end


function [sen,spec,PPV,NPV,accuracy,f1] = evaluation_metric(interaction_score,predict_score)
    max_value = max(predict_score);
    min_value = min(predict_score);
    threshold = min_value+(max_value-min_value)*(1:999)/1000;
    for i = 1 : 999
       predict_label = (predict_score>threshold(i));
       [temp_sen(i),temp_spec(i),temp_ppv(i),temp_npv(i),temp_accuracy(i),temp_f1(i)] = classification_metric(interaction_score,predict_label);
    end
    [~,index] = max(temp_f1);  %% ����f1�ﵽ���ֵ�������ݵ���ֵ����ѡ��Ӧ��metrics
    sen = temp_sen(index);
    spec = temp_spec(index);
    PPV = temp_ppv(index);
    NPV = temp_npv(index);
    accuracy = temp_accuracy(index);
    f1 = temp_f1(index);
end

function [sen,spec,PPV,NPV,accuracy,f1] = classification_metric(real_label,predict_label)
    tp_index=find(real_label==1 & predict_label==1);
    tp=size(tp_index,1);
    tn_index=find(real_label==0 & predict_label==0);
    tn=size(tn_index,1);
    fp_index=find(real_label==0 & predict_label==1);
    fp=size(fp_index,1);
    fn_index=find(real_label==1 & predict_label==0);
    fn=size(fn_index,1);
    accuracy=(tn+tp)/(tn+tp+fn+fp);
    sen=tp/(tp+fn);
    recall=sen;
    spec=tn/(tn+fp);
    precision=tp/(tp+fp);
    PPV = precision;
    NPV = tn / (tn + fn);
    f1=2*recall*precision/(recall+precision);
end

function area = AUPR(real,predict)
    max_value = max(predict);
    min_value = min(predict);
    threshold = min_value+(max_value-min_value)*(1:999)/1000;
    threshold = threshold';
    threshold_num = length(threshold);
    tn = zeros(threshold_num,1);
    tp = zeros(threshold_num,1);
    fn = zeros(threshold_num,1);
    fp = zeros(threshold_num,1);
    for i=1:threshold_num
        tp_index=logical(predict>=threshold(i) & real==1);
        tp(i,1)=sum(tp_index);
        tn_index=logical(predict<threshold(i) & real==0);
        tn(i,1)=sum(tn_index);
        fp_index=logical(predict>=threshold(i) & real==0);
        fp(i,1)=sum(fp_index);
        fn_index=logical(predict<threshold(i) & real==1);
        fn(i,1)=sum(fn_index);
    end
    sen=tp./(tp+fn);
    precision=tp./(tp+fp);
    recall=sen;
    x=recall;
    y=precision;
    [x,index]=sort(x);
    y=y(index,:);
    area=0;
    x(1,1)=0;
    y(1,1)=1;
    x(threshold_num+1,1)=1;
    y(threshold_num+1,1)=0;
    area=0.5*x(1)*(1+y(1));
    for i=1:threshold_num
        area=area+(y(i)+y(i+1))*(x(i+1)-x(i))/2;
    end
    hold on;
    plot(x,y);
end

function area=AUC(real,predict)
    max_value=max(predict);
    min_value=min(predict);
    threshold=min_value+(max_value-min_value)*(1:999)/1000;
    threshold=threshold';
    threshold_num=length(threshold);
    tn=zeros(threshold_num,1);
    tp=zeros(threshold_num,1);
    fn=zeros(threshold_num,1);
    fp=zeros(threshold_num,1);
    for i=1:threshold_num
        tp_index=logical(predict>=threshold(i) & real==1);
        tp(i,1)=sum(tp_index);
        tn_index=logical(predict<threshold(i) & real==0);
        tn(i,1)=sum(tn_index);
        fp_index=logical(predict>=threshold(i) & real==0);
        fp(i,1)=sum(fp_index);
        fn_index=logical(predict<threshold(i) & real==1);
        fn(i,1)=sum(fn_index);
    end
    sen=tp./(tp+fn);
    spe=tn./(tn+fp);
    y=sen;
    x=1-spe;
    [x,index]=sort(x);
    y=y(index,:);
    [y,index]=sort(y);
    x=x(index,:);
    area=0;
    x(threshold_num+1,1)=1;
    y(threshold_num+1,1)=1;
    area=0.5*x(1)*y(1);
    for i=1:threshold_num
        area=area+(y(i)+y(i+1))*(x(i+1)-x(i))/2;
    end
%     hold on;
%     plot(x,y);
end

function similarity_matrix = get_similarity_matrix(interaction_matrix)
    %get intersection matrix
    intersection_matrix = interaction_matrix * interaction_matrix';
    %get denominator matrix
    protein_degree_matrix = sum(interaction_matrix, 2);
    denominator_matrix = sqrt(protein_degree_matrix * protein_degree_matrix');
    %calculate similarity_matrix of protein
    similarity_matrix = intersection_matrix ./ denominator_matrix;
    similarity_matrix(isnan(similarity_matrix)) = 0;
end

function rna_similarity_matrix = get_ran_similarity_matrix(interaction_matrix)
    rna_similarity_matrix = corrcoef(interaction_matrix);
    rna_similarity_matrix(isnan(rna_similarity_matrix)) = 0;
    rna_similarity_matrix = abs(rna_similarity_matrix);
end

function protein_similarity_matrix = get_protein_similarity_matrix(interaction_matrix)
    %get intersection matrix
    intersection_matrix = interaction_matrix * interaction_matrix';
    %get denominator matrix
    protein_degree_matrix = sum(interaction_matrix, 2);
    denominator_matrix = sqrt(protein_degree_matrix * protein_degree_matrix');
    %calculate similarity_matrix of protein
    protein_similarity_matrix = intersection_matrix ./ denominator_matrix;
    protein_similarity_matrix(isnan(protein_similarity_matrix)) = 0;
end