% Case Study for COVID-19
% implement virus-drug association prediction by the model EMC-Voting 
% novel virus test
    clc
    clear
    warning('off');
    addpath('E:\000 COVID-19\01 DLMC-master\DrugVirus\BalancedData_DrugVirus');
    load interaction.mat;
    interaction_matrix = LD;
%     interaction_matrix(1,:)=0; %% novel virus just like no known associations
    
    [m1,n2] = size(LD);
    VS = load('microbesimilarity.txt');
    VF = load('microbefeatures.txt');
    DS = load('drugsimilarity.txt');
    DF = load('drugfeatures.txt'); 
    
    virus_Name = importdata('virusList.txt');
    drug_Name = importdata('drugList.txt');
    test_mask = ones(m1,n2);
    trIndex = double(interaction_matrix ~= 0);
    
    [row,col]=size(interaction_matrix);    
    predict_matrix_2 = alg_BNNR(interaction_matrix,VS,DS);
    predict_matrix_3 = alg_FRMC(interaction_matrix,VS,DS);
    predict_matrix_6 = alg_HGIMC(interaction_matrix,VS,DS,trIndex);
    predict_matrix_7 = alg_GRMF(interaction_matrix,VS,DS);  
    
    proba_2 = predict_matrix_2(:);
    proba_3 = predict_matrix_3(:);
    proba_6 = predict_matrix_6(:);
    proba_7 = predict_matrix_7(:);  
    model_list = [proba_2 proba_3 proba_6 proba_7];
    weights = [0.26, 0.26, 0.25, 0.23];       
    
    predict_matrix = alg_EnsembleVoting(interaction_matrix, model_list, weights, 'soft');    
    F = predict_matrix;   
    
    for i=1:m1
        for j=1:n2
            if interaction_matrix(i,j)==1
               F(i,j)=-10000;                 %%�������������֪�����ķ�����Ϊ1
            end
        end
    end    
[rankresult,rank_score,known_assoccition_rank] =Rank(F',interaction_matrix',drug_Name,virus_Name);
Write_file( rankresult );          
save CaseStudy rankresult;
save rankscore_CaseStudy rank_score;           
save known_assoccition_CaseStudy known_assoccition_rank; 
       
    disp('Case study ends!')    
    addr = 'results\';    
    prefix = 'CaseStudy_EMC_COVID19';
    fdatestr =datestr(now,'mmm.dd-HH.MM.SS');
    fout = [addr,prefix,'_',fdatestr,'.mat'];
    save(fout, 'predict_matrix');

 function [ranklncRNAs_result,scores_sortPredict,known_assoccition_rank] = Rank(predictresult,LDmatrix,lncRNAs_name,diseases_name )
    [rows,cols]=size(LDmatrix);
    num_ones=zeros(cols,1);
    for i=1:cols
       num_ones(i,1)=nnz(LDmatrix(:,i)); 
    end
    num=rows-min(num_ones);
%    ranklncRNAs_result=cell(num+1,cols);  
    known_assoccition_rank=zeros(size(LDmatrix)); 
    [scores_sortPredict,~]=sort( predictresult,1,'descend'); %%�Ծ���ĸ��зֱ�������
    for i=1:cols
       idx=find(LDmatrix(:,i));  
       [~,idx_sort]=sort(predictresult(:,i),'descend');
       
       known_assoccition_rank(:,i)=ismember(idx_sort,idx);         
       for j=1:length(idx)  
          del_idx= (idx(j,1)==idx_sort);
          idx_sort(del_idx,:)=[];
       end
       ranklncRNAs_result(1,i)=diseases_name(i,1);  
       for k=1:length(idx_sort)
          ranklncRNAs_result(k+1,i)=lncRNAs_name(idx_sort(k,1)); 
       end        
    end
 end
 
 function Write_file( Result )
       [rows, cols] = size (Result);    
       fid=fopen ( '.\ResultCaseStudy2.xls', 'w');
       for i = 1:rows
           for j = 1:cols
               fprintf(fid, '%s\t', Result{i,j});
           end
           fprintf(fid, '\n');
       end
       fclose(fid);      
 end
    
function score_matrix = alg_BNNR(LD,LS,DS)
[nd,nm]=size(LD);
% [kd,km] = gaussiansimilarity(LD,nd,nm);
sm = get_ran_similarity_matrix(LD);
sd = get_protein_similarity_matrix(LD);
Wrr = (DS+sm)/2;
Wdd = (LS+sd)/2;
% Wrr = DS;
% Wdd = LS;
Wdr = LD;
[dn,dr] = size(Wdr);

alpha = 10;
beta = 10;

maxiter = 300;
tol1 = 2*1e-3;
tol2 = 1*1e-5;
T = [Wrr, Wdr'; Wdr, Wdd];
[t1, ~] = size(T);
trIndex = double(T ~= 0);
[WW,~] = BNNR(alpha, beta, T, trIndex, tol1, tol2, maxiter, 0, 1);
M_recovery = WW((t1-dn+1):t1,1:dr);
score_matrix = M_recovery;
end

function score_matrix = alg_FRMC(LD,LS,DS)
addpath('E:\000 COVID-19\01 DLMC-master\helper_functions');
    [m1,n2]=size(LD);
    Adj=[LS,LD;LD',DS];
    interaction=LD;
    index=find(LD);
    [pp,qq]=size(index);
    A=zeros(pp,2);
    for i=1:pp
    [lncRNA,disease]=ind2sub(size(LD),index(i));
    A(i,1)=lncRNA;
    A(i,2)=disease;
    end
    tol = 0.1;
    ran =[0,1];
    
    i_reuse = 50;
    q_reuse = 10;   

    Adj1=[DS,interaction';interaction,LS]; 
    M = sparse(Adj1);
    t = cputime;
    [X] = fastSVT_Q(M, tol, ran, i_reuse, q_reuse);  %%tol=0.15, ran=[0,1], i_reuse=50,q_reuse=10
    t_SVT = cputime - t;
    F=X((n2+1):(n2+m1),1:n2);
    score_matrix = F;
end

function score_matrix = alg_HGIMC(interaction_matrix,VS,DS,trIndex)
A_DR = interaction_matrix;
[nd,nm] = size(interaction_matrix);   
D = VS;
R = DS;
alpha = 10; 
beta = 10; 
gamma = 0.7;
threshold = 0.5;
sigma=0.5;
    maxiter = 300; 
    tol1 = 2*1e-3;   
    tol2 = 1*1e-5;
    % 2.1 Bounded Matrix Completion
    [A_bmc, ~] = fBMC(alpha, beta, A_DR, trIndex, tol1, tol2, maxiter, 0, 1);
    A_DR0 = A_bmc.*double(A_bmc > threshold);
    % 2.2 Gaussian Radial Basis function
    A_DD = fGRB(D, sigma);                     %% sigma=0.5
    A_RR = fGRB(R, sigma);
% 2.3 Heterogeneous Graph Inference 
    score_matrix = fHGI(gamma, A_DD, A_RR, A_DR0);
end

function score_matrix = alg_GRMF(Y,Sd,St)
%alg_grmf predicts DTIs based on the algorithm described in the following paper: 
% Ali Ezzat, Peilin Zhao, Min Wu, Xiao-Li Li and Chee-Keong Kwoh
% (2016) Drug-target interaction prediction with graph-regularized matrix factorization
% INPUT:
%  Y:           interaction matrix
%  Sd:          pairwise row similarities matrix
%  St:          pairwise column similarities matrix
%  test_ind:    indices of test set instances
% OUTPUT:
%  y3:          prediction matrix
%    % parameters 

   global num_iter p k lambda_l lambda_v lambda_d
   num_iter=2; k=85; p=5; 
   lambda_l=2;lambda_v=0.1; lambda_d=0.1;
   
    Sd = preprocess_PNN(Sd,p);
    St = preprocess_PNN(St,p);
    % Laplacian Matrices
    Dd = diag(sum(Sd));
    Ld = Dd - Sd;
     Ld = (Dd^(-0.5))*Ld*(Dd^(-0.5));
    Dt = diag(sum(St));
    Lt = Dt - St;
     Lt = (Dt^(-0.5))*Lt*(Dt^(-0.5));
    % (W)GRMF
    [A,B] = initializer(Y,k);	% initialize A & B
%     W = ones(size(Y));          % weight matrix W
%     W(test_ind) = 0;            % set W=0 for test instances
    [A,B] = alg_grmf_predict(Y,A,B,Ld,Lt,lambda_l,lambda_v,lambda_d,num_iter);    % update A & B
    % compute prediction matrix
    score_matrix = A*B';
end

function score_matrix = alg_EnsembleVoting(A, modellist, weights, mode)
[row, col] = size(modellist);
voting_proba = zeros(row,1);
voting_label = zeros(row,1);
all_proba = modellist;
    if mode == 'soft'
        for i = 1 : row
             for j = 1:col
                 voting_proba(i) = voting_proba(i)+all_proba(i,j)*weights(j);
             end
             voting_proba(i) = voting_proba(i)/sum(weights);
             if voting_proba(i) >= 0.5
                 voting_label(i) = 1;
             else
                 voting_label(i) = 0;
             end
        end
    elseif mode == 'hard'
        for i = 1 : row
            val1=0; val2=0; len1=0; len2=0; weights_1=0; weights_2=0;
            for j = 1:col
               if all_proba(i,j) >= 0.5
                   val2 = val2 + all_proba(i,j)*weights(j);
                   weights_2 = weights_2+weights(j);
                   len2 = len2+1;
               elseif all_proba(i,j) < 0.5
                   val1 = val1 + all_proba(i,j)*weights(j); 
                   weights_1 = weights_1+weights(j);
                   len1 = len1+1;
               end 
            end
            if len2 >= 2
                voting_proba(i) = val2/weights_2;
                voting_label(i) = 1;
            elseif len1 >= 2
                voting_proba(i) = val1/weights_1;
                voting_label(i) = 0;
            end
        end
    end
    [m,n] = size(A);
    score_matrix = reshape(voting_proba,m,n);
end

function [S]=preprocess_PNN(S,p)
%preprocess_PNN sparsifies S by keeping, for each drug/virus, the "p"
% nearest neighbors (NNs) and discarding the rest. 
    NN_mat = zeros(size(S));
    for j=1:length(NN_mat)
        [~,indx] = sort(S(j,:),'descend');
        indx = indx(1:p+1);     % keep drug/virus j and its "p" NNs
        NN_mat(j,indx) = 1;
    end
    NN_mat = (NN_mat+NN_mat')/2;
    S = NN_mat .* S;
end

function [A,B]=initializer(Y,k)
%initializer initializes the A and B latent feature matrices for either
% of the CMF or GRMF algorithms.%
% INPUT:
%  Y:   interaction matrix
%  k:   number of latent features%
% OUTPUT:
%  A:   latent feature matrix for drugs
%  B:   latent feature matrix for targets
[u,s,v] = svds(Y,k);
A = u*(s^0.5);
B = v*(s^0.5);
    %     % Alternative: Use non-negative matrix factorization
%     k = min(k, min(size(Y)));
%     [A,B] = nnmf(Y,k);
%     B = B';
end

function [A,B]=alg_grmf_predict(Y,A,B,Ld,Lt,lambda_l,lambda_d,lambda_t,num_iter,W)
%alg_grmf_predict performs alternating least squares for GRMF
%
% INPUT:
%  Y:           interaction matrix
%  A:           drug latent feature matrix
%  B:           target latent feature matrix
%  Ld:          drug graph Laplacian
%  Lt:          target graph Laplacian
%  lambda_ldt:  regularization parameters
%  num_iter:    number of iterations for alternating least squares
%  W:           weight matrix
%
% OUTPUT:
%  A:           updated drug latent feature matrix
%  B:           updated target latent feature matrix
%
    K = size(A,2);
    lambda_d_Ld = lambda_d*Ld;          % to avoid 
    lambda_t_Lt = lambda_t*Lt;          % repeated matrix 
    lambda_l_eye_K = lambda_l*eye(K);   % multiplications
    % if no weight matrix is supplied or W is an all-ones matrix...
    if nargin < 10 || isequal(W,ones(size(W)))
        %%%%%%%%%%%%
        %%% GRMF %%%
        %%%%%%%%%%%%
        for z=1:num_iter
            A = (Y*B  - lambda_d_Ld*A) / (B'*B + lambda_l_eye_K);
            B = (Y'*A - lambda_t_Lt*B) / (A'*A + lambda_l_eye_K);
        end 
    else
        %%%%%%%%%%%%%
        %%% WGRMF %%%
        %%%%%%%%%%%%%
        H = W .* Y;
        for z=1:num_iter
%             % for readability...
%             A_old = A;
%             for i=1:size(A,1)
%                 A(i,:) = (H(i,:)*B - lambda_d*Ld(i,:)*A_old) / (B'*diag(W(i,:))*B + lambda*eye(k));
%             end
%             B_old = B;
%             for j=1:size(B,1)
%                 B(j,:) = (H(:,j)'*A - lambda_t*Lt(j,:)*B_old) / (A'*diag(W(:,j))*A + lambda*eye(k));
%             end
            % equivalent, less readable, faster
            A_old = A;
            HB_minus_alpha_Ld_A_old = H*B - lambda_d_Ld*A_old;
            for a=1:size(A,1)
                A(a,:) = HB_minus_alpha_Ld_A_old(a,:) / (B'*diag(W(a,:))*B + lambda_l_eye_K);
            end
            B_old = B;
            HtA_minus_beta_Lt_B_old = H'*A - lambda_t_Lt*B_old;
            for b=1:size(B,1)
                B(b,:) = HtA_minus_beta_Lt_B_old(b,:) / (A'*diag(W(:,b))*A + lambda_l_eye_K);
            end
        end
    end
    
end

function [sd,sm] = integratedsimilarity(FS,FSP,SS,SSP,kd,km)         
sm = FS.*FSP+km.*(-(FSP-1));            
sd = SS.*SSP+kd.*(-(SSP-1));            
end

function [kd,km] = gaussiansimilarity(interaction,nd,nm)
%A: Binary relations between disease and miRNA, 1st column:miRNA, 2nd column:disease
%calculate gamad for Gaussian kernel calculation
 gamad = nd/(norm(interaction,'fro')^2);
%calculate Gaussian kernel for the similarity between disease: kd
C=interaction;
kd=zeros(nd,nd);
D=C*C';
for i=1:nd
    for j=i:nd
        kd(i,j)=exp(-gamad*(D(i,i)+D(j,j)-2*D(i,j)));
    end
end
kd=kd+kd'-diag(diag(kd));
%calculate gamam for Gaussian kernel calculation
gamam = nm/(norm(interaction,'fro')^2);
%calculate Gaussian kernel for the similarity between miRNA: km
km=zeros(nm,nm);
E=C'*C;
for i=1:nm
    for j=i:nm
        km(i,j)=exp(-gamam*(E(i,i)+E(j,j)-2*E(i,j)));
    end
end
km=km+km'-diag(diag(km));
end

function similarity_matrix = get_similarity_matrix(interaction_matrix)
    %get intersection matrix
    intersection_matrix = interaction_matrix * interaction_matrix';
    %get denominator matrix
    protein_degree_matrix = sum(interaction_matrix, 2);
    denominator_matrix = sqrt(protein_degree_matrix * protein_degree_matrix');
    %calculate similarity_matrix of protein
    similarity_matrix = intersection_matrix ./ denominator_matrix;
    similarity_matrix(isnan(similarity_matrix)) = 0;
end

function rna_similarity_matrix = get_ran_similarity_matrix(interaction_matrix)
    rna_similarity_matrix = corrcoef(interaction_matrix);
    rna_similarity_matrix(isnan(rna_similarity_matrix)) = 0;
    rna_similarity_matrix = abs(rna_similarity_matrix);
end

function protein_similarity_matrix = get_protein_similarity_matrix(interaction_matrix)
    %get intersection matrix
    intersection_matrix = interaction_matrix * interaction_matrix';
    %get denominator matrix
    protein_degree_matrix = sum(interaction_matrix, 2);
    denominator_matrix = sqrt(protein_degree_matrix * protein_degree_matrix');
    %calculate similarity_matrix of protein
    protein_similarity_matrix = intersection_matrix ./ denominator_matrix;
    protein_similarity_matrix(isnan(protein_similarity_matrix)) = 0;
end